import React, { useEffect, useRef } from "react";
import { View, Text, Animated, Easing, Dimensions } from "react-native";
import { styles, DIAMETRO } from "../../../screen/css/OndaStyle";

const LARGURA_TELA = Dimensions.get("window").width;

// Quantidade de bolhas necessárias para cobrir a tela inteira
// (+2 para sobrar espaço enquanto a faixa desliza)
const QUANTIDADE_BOLHAS = Math.ceil(LARGURA_TELA / DIAMETRO) + 2;
const bolhas = Array.from({ length: QUANTIDADE_BOLHAS });


export const Onda = ({ porcentagem = 0, altura = "56%" }) => {
  const progresso = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Vai de 0 a 1 em loop; cada crista converte isso em deslocamento
    const animacao = Animated.loop(
      Animated.timing(progresso, {
        toValue: 1,
        duration: 4000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    animacao.start();
    return () => animacao.stop();
  }, [progresso]);

  // Crista da frente anda para a esquerda, a de trás para a direita.
  // Como a faixa desliza exatamente uma bolha, o loop fica contínuo.
  const deslocaFrente = progresso.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -DIAMETRO],
  });

  const deslocaFundo = progresso.interpolate({
    inputRange: [0, 1],
    outputRange: [-DIAMETRO, 0],
  });

  return (
    <View style={[styles.container, { height: altura }]}>
      {/* crista de trás (mais clara) */}
      <Animated.View
        style={[
          styles.crista,
          styles.cristaFundo,
          { transform: [{ translateX: deslocaFundo }] },
        ]}
      >
        {bolhas.map((_, i) => (
          <View key={i} style={[styles.bolha, styles.bolhaFundo]} />
        ))}
      </Animated.View>

      {/* corpo da água */}
      <View style={styles.agua} />

      {/* crista da frente */}
      <Animated.View
        style={[styles.crista, { transform: [{ translateX: deslocaFrente }] }]}
      >
        {bolhas.map((_, i) => (
          <View key={i} style={styles.bolha} />
        ))}
      </Animated.View>

      {/* etiqueta com a porcentagem */}
      <View style={styles.etiqueta}>
        <View style={styles.etiquetaCaixa}>
          <Text style={styles.etiquetaTexto}>{porcentagem}%</Text>
        </View>
        <View style={styles.etiquetaPonta} />
      </View>
    </View>
  );
};
