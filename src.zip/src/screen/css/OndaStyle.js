import { StyleSheet } from "react-native";
import color from "../Colors/cor";

// Tamanho de cada "bolha" que forma a crista da onda.
// O componente Onda usa esse mesmo valor para calcular a animação.
export const DIAMETRO = 90;

export const styles = StyleSheet.create({
  // Ocupa a parte de baixo da tela; a altura é controlada pelo componente
  container: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    overflow: "hidden",
  },

  // Corpo da "água" (bloco sólido abaixo da crista)
  agua: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    top: DIAMETRO / 2,
    backgroundColor: color.colorModelThree,
  },

  // Faixa de bolhas que forma a crista
  crista: {
    position: "absolute",
    left: -DIAMETRO,
    top: 0,
    flexDirection: "row",
  },

  bolha: {
    width: DIAMETRO,
    height: DIAMETRO,
    borderRadius: 35,
    backgroundColor: color.colorModelThree,
  },

  // Segunda crista, mais clara e atrás, para dar profundidade (efeito mar)
  cristaFundo: {
    top: -10,
    left: -DIAMETRO / 2,
  },

  bolhaFundo: {
    backgroundColor: color.colorModelTwo,
    opacity: 0.7,
  },

  // ---------- Etiqueta "24%" ----------
  etiqueta: {
    position: "absolute",
    left: 0,
    top: DIAMETRO / 2 + 14,
    flexDirection: "row",
    alignItems: "center",
  },

  etiquetaCaixa: {
    backgroundColor: color.branco,
    paddingVertical: 8,
    paddingHorizontal: 18,
    borderTopRightRadius: 4,
    borderBottomRightRadius: 4,
  },

  etiquetaTexto: {
    fontSize: 22,
    fontWeight: "600",
    color: color.colorModelOne,
  },

  // Pontinha branca à direita (triângulo feito com bordas)
  etiquetaPonta: {
    width: 0,
    height: 0,
    borderTopWidth: 20,
    borderBottomWidth: 20,
    borderLeftWidth: 12,
    borderTopColor: "transparent",
    borderBottomColor: "transparent",
    borderLeftColor: color.branco,
  },
});

export default styles;
